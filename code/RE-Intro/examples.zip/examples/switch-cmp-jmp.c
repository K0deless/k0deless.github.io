#include <stdio.h>
#include <stdlib.h>

int
main()
{
	printf("Press a character to move (wasd): ");
	char c = getchar();
	fflush(stdin);

	switch(c)
	{
	case 'w':
		printf("\nMove Forward\n");
		break;
	case 'a':
		printf("\nMove Left\n");
		break;
	case 's':
		printf("\nMove Backward\n");
		break;
	case 'd':
		printf("\nMove Right\n");
		break;
	default:
		printf("\nThat's not a movement key...\n");
		return -1;
	}

	return 0;
}
