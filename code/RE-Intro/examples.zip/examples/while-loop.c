#include <stdio.h>

int
main()
{
	int user_value = 0;

	printf("Write the correct number between 1 and 20: ");
	scanf("%d", &user_value);
	fflush(stdin);

	while(user_value != 17)
	{
		printf("That's not the correct number, write other: ");
		scanf("%d", &user_value);
		fflush(stdin);
	};

	printf("Yeahhhh, that's the number\n");

	return 0;
}
