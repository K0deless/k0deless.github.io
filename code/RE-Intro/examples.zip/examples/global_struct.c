#include <stdio.h>
#include <stdlib.h>

typedef struct user_
{
	char name[30];
	int age;
	short id;
} user_t;


user_t user_var;
size_t user_ids = 0;

int
main(int argc, char **argv)
{
	printf("Write user name: ");

	if(fgets(user_var.name, 29, stdin) == NULL)
	{
		printf("Error reading user name...\n");
		return -1;
	}
	
	printf("Write user age: ");
	scanf("%d", &user_var.age);
	fflush(stdin);

	printf("The id assigned is: %ld\n", user_ids);

	user_var.id = user_ids++;

	printf("User information:\n\tUser name: %s\n\tUser age: %d\n\tUser id: %d\n", user_var.name, user_var.age, user_var.id);

	return 0;
}
