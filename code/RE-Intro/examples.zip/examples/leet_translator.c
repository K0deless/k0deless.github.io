#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void
translate_to_l33t(char **argv, int number_of_strings)
{
	int i, j;
	size_t len;
	for (i = 1; i <= number_of_strings; i++)
	{
		len = strlen(argv[i]);

		for (j = 0; j < len; j++)
		{
			argv[i][j] = argv[i][j] & ~0x20;

			switch(argv[i][j])
			{
				case 'A':
					printf("4");
					break;
				case 'B':
					printf("|3");
					break;
				case 'D':
					printf("|)");
					break;
				case 'E':
					printf("3");
					break;
				case 'G':
					printf("6");
					break;
				case 'H':
					printf("|-|");
					break;
				case 'I':
					printf("1");
					break;
				case 'K':
					printf("|<");
					break;
				case 'M':
					printf("|\\/|");
					break;
				case 'N':
					printf("|\\|");
					break;
				case 'O':
					printf("0");
					break;
				case 'Q':
					printf("()_");
					break;
				case 'R':
					printf("I2");
					break;
				case 'S':
					printf("5");
					break;
				case 'T':
					printf("7");
					break;
				case 'V':
					printf("\\/");
					break;
				case 'W':
					printf("\\/\\/");
					break;
				case 'Z':
					printf("2");
					break;
				default:
					printf("%c", argv[i][j]);
					break;	
			}
		}
		printf(" ");
	}
	printf("\n");
}

int
main(int argc, char **argv)
{
	int i = 0;
	if (argc == 1)
	{
		printf("USAGE: %s <string1> <string2> ... <stringN>\n", argv[0]);
		exit(-1);
	}

	printf("Welcome to l33t translator...\n");
	
	translate_to_l33t(argv, argc-1);
	
	return 0;
}
