#include <stdio.h>

int
main()
{
	int a, b, c, d;

	a = 5;
	b = 2;
	
	c = a/b;
	d = a%b;

	return 0;
}
