#include <stdio.h>

int global_array[10];

int
main()
{
	int i = 0;

	for (i = 0; i < 10; i++)
	{
		global_array[i] = i * 10;
	}

	printf("Values from global array:\n");
	for (i = 0; i < 10; i++)
	{
		printf("global_array[%d] = %d\n", i, global_array[i]);
	}

	return 0;
}
