#include <stdio.h>
#include <stdlib.h>


int global_array[4];
char str_as_array[12];

int
main(int argc, char **argv)
{
	global_array[0] = 0x11223344;
	global_array[1] = 0x20;
	global_array[2] = 0;
	global_array[3] = 0x99887766;

	str_as_array[0] = 'H';
	str_as_array[1] = 'e';
	str_as_array[2] = 'l';
	str_as_array[3] = 'l';
	str_as_array[4] = 'o';
	str_as_array[5] = ' ';
	str_as_array[6] = 'W';
	str_as_array[7] = 'o';
	str_as_array[8] = 'r';
	str_as_array[9] = 'l';
	str_as_array[10] = 'd';
	str_as_array[11] = 0;

	printf("%s\n", str_as_array);

	return -1;
}

