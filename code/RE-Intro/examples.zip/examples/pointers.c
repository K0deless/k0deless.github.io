#include <stdio.h>
#include <stdlib.h>

// go to bss section
char global_str[8];

int
main()
{
	int val = 4;
	int *p_val, *p_global_str;

	p_val = &val;

	printf("Value of val: %d\n", val);

	*(p_val) = 10;

	printf("Value now of val: %d\n", val);

	p_global_str = (int*)global_str;

	*(p_global_str) = 0x52554f59;
	*(p_global_str+1) = 0x004b434f;

	printf("The global_str: %s\n", global_str);

	return 0;
}
