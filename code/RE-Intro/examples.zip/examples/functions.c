#include <stdio.h>
#include <stdlib.h>

int
add(int a, int b)
{
	return a+b;
}

int
sub(int a, int b)
{
	return a-b;
}

void
not_called(int a, char b, float c, void *some_value)
{
	printf("Do not look at this function, because it's not called\n");
}

int
main(int argc, char **argv)
{
	printf("Let's going to see some simple functions...\n");

	printf("20+16=%d\n", add(16, 20));

	printf("44-22=%d\n", sub(44, 22));

	printf("Something more found in this program?\n");

	return 0;
}
