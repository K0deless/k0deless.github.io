#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int
main(int argc, char **argv)
{
	unsigned long long user_number;
	char *pEnd;

	if (argc != 2)
	{
		printf("ERROR: %s <number>\n", argv[0]);
		exit(-1);
	}

	errno = 0;

	user_number = strtoull(argv[1], &pEnd, 10);

	if (user_number == 0 && errno != 0 || argv[1] == pEnd)
	{
		printf("Nooo that's not a correct number...\n");
		exit(-1);
	}

	printf("Checking if your number is correct...\n");

	if (user_number == 0x1122334455667788)
	{
		printf("Number is correct, well done!\n");
	}
	else
	{
		printf("Nooooo... That's not the number I'm looking for...\n");
	}

	exit(0);
}
