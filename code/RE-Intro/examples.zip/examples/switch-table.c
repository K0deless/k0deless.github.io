#include <stdio.h>
#include <stdlib.h>


int
main()
{
	int i = 0;
	printf("Write a number between 1 and 10: ");
	scanf("%d", &i);
	fflush(stdin);

	switch(i)
	{
	case 1:
		printf("Your number is 1\n");
		break;
	case 2:
		printf("Your number is 2\n");
		break;
	case 3:
		printf("Your number is 3\n");
		break;
	case 4:
		printf("Your number is 4\n");
		break;
	case 5:
		printf("Your number is 5\n");
		break;
	case 6:
		printf("Your number is 6\n");
		break;
	case 7:
		printf("Your number is 7\n");
		break;
	case 8:
		printf("Your number is 8\n");
		break;
	case 9:
		printf("Your number is 9\n");
		break;
	case 10:
		printf("Your number is 10\n");
		break;
	default:
		printf("Your number sucks\n");
		return -1;
	}

	return 0;
}
