#include <stdio.h>
#include <stdlib.h>

int global_var = 0;
char *global_str = "This is a global string";


int
main()
{
	global_var = 5;

	printf("%s\n", global_str);
	printf("global var = %d\n", global_var);

	exit(0);
}
